from functools import wraps
from django.http import HttpResponseRedirect


def public_api(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        return function(request, *args, **kwargs)
    func = wrap
    func.is_public_api = True
    return wrap


def public_view(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        return function(request, *args, **kwargs)
    func = wrap
    func.is_public_view = True
    return wrap


def hr_login_required(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        return function(request, *args, **kwargs)
    func = wrap
    func.hr_login_required = True
    return wrap


def is_login_view(function):
    @wraps(function)
    def wrap(request, *args, **kwargs):
        return function(request, *args, **kwargs)
    func = wrap
    func.is_login_view = True
    return wrap


