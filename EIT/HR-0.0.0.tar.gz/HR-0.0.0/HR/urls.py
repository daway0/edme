from django.urls import path
from HR.api import (
    AllUsers,
    GetUser,
    GetUserTeamRole,
    GetUserRoles,
    ExistsUsers,
    ExistsRole,
    GetUserTeamRoles,
)
from HR.backends import show_404,show_403

app_name = "HR"
urlpatterns = [
    path('api/all-users/', AllUsers.as_view(), name="all_users" ),
    path('api/get-user/<str:username>/', GetUser.as_view(), name="get_user" ),
    path('api/get-user-team-role/<str:username>/', GetUserTeamRole.as_view(), name="get_user_team_role" ),
    path('api/get-user-team-roles/', GetUserTeamRoles.as_view(), name="get_user_team_roles" ),
    path('api/get-user-roles/<str:username>/', GetUserRoles.as_view(), name="get_user_roles" ),

    # check exists api
    path('api/exists-users/<str:pk>/', ExistsUsers.as_view(), name="exists_users" ),
    path('api/exists-role/<str:pk>/', ExistsRole.as_view(), name="exists_role" ),


]