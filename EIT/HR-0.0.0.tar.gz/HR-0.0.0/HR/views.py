
# from datetime import datetime
import json

from HR.utils import call_api_post
from HR.jwt import init_tokens
# from django.db.models import F, ExpressionWrapper, fields
# from HR import models as HRMODEL
from django.http.response import JsonResponse
from rest_framework import status
from django.contrib.auth.decorators import login_required



# def get_user_teamrole(request,teamcode,roleid,levelid,superior):
#     userTeamRole = HRMODEL.UserTeamRole.objects.filter(RoleId__RoleId=roleid,TeamCode__TeamCode=teamcode,LevelId=levelid
#                                                   ,Superior=superior).values('UserName__UserName','UserName__FirstName','UserName__LastName','UserName__FieldOfStudy','UserName__BirthDate')
#
#     duration = ExpressionWrapper(datetime.now().date() - F('UserName__BirthDate'), output_field=fields.DurationField())
#
#     data = HRMODEL.UserTeamRole.objects.filter(RoleId__RoleId=roleid, TeamCode__TeamCode=teamcode, LevelId=levelid
#                                    , Superior=superior).annotate(duration=duration)
#     print(data)
#     return "a"



@login_required
def get_internal_token(request):
    if request.user.is_superuser:
        token = init_tokens(request.user.UserName)
        return JsonResponse({'state':'ok','token':token},status=200)
    return JsonResponse({'state': 'error'}, status=400)