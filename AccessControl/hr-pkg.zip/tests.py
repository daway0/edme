from django.test import TestCase
class a():
    pass
