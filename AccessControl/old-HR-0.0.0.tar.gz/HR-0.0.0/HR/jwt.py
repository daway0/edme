import jwt
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import base64
import datetime
from HR.env import *
from django.contrib.auth.models import User
import pytz


def encrypt(message):
    message = str.encode(message)
    key = RSA.import_key(APP_USER_PUBLIC_KEY)
    cipher = PKCS1_OAEP.new(key)
    ciphertext = cipher.encrypt(message)
    ciphertext = base64.b64encode(ciphertext)
    return ciphertext


def decrypt(ciphertext):
    ciphertext = base64.b64decode(ciphertext)
    key = RSA.import_key(APP_USER_PRIVATE_KEY)
    cipher = PKCS1_OAEP.new(key)
    plaintext = cipher.decrypt(ciphertext)
    return plaintext.decode("utf-8")


def check(access):
    ret = False
    try:
        decodeJTW = jwt.decode(access,APP_USER_SECRET_KEY, algorithms=["HS256"])
        now = int(datetime.datetime.now(pytz.timezone('Asia/Tehran')).timestamp())
        exp = int(decodeJTW['exp'])
        user = decodeJTW['UserName']
        if exp > now:
            if User.objects.filter(username=user, is_superuser=True, is_active=True, is_staff=True).exists():
                ret = True
    except:
        ret = False

    return ret

def init_tokens(user):
    user = str(user).lower()
    decodeJTW = {}
    decodeJTW['UserName'] = user
    decodeJTW['TokenDate'] = int(datetime.datetime.now(pytz.timezone('Asia/Tehran')).timestamp())
    decodeJTW['exp'] = datetime.datetime.now(pytz.timezone('Asia/Tehran')) + datetime.timedelta(minutes=5)
    encoded = jwt.encode(decodeJTW, APP_USER_SECRET_KEY, algorithm="HS256")
    return str(encoded)